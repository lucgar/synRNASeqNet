.__global__ <-
  "counts"
