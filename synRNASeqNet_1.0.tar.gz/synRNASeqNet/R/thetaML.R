thetaML <-
function(cellCounts) cellCounts/sum(cellCounts)
